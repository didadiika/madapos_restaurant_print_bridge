import 'package:flutter/foundation.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';

import '../models/printer_model.dart';
import '../constants/printer_connection.dart';

class PrinterManagerService {
  static PrinterModel? _currentPrinter;

  /// Pastikan printer tujuan sudah terkoneksi.
  static Future<void> ensureConnected(PrinterModel printer) async {
    if (printer.connection == PrinterConnection.network) {
      // Ethernet tidak perlu persistent connection.
      _currentPrinter = printer;
      return;
    }

    if (_isSamePrinter(printer)) {
      final connected = await PrintBluetoothThermal.connectionStatus;
      if (connected) {
        debugPrint('Printer sudah terkoneksi.');
        return;
      }
    }

    // Printer berbeda atau koneksi putus.
    await _disconnectCurrent();

    debugPrint('Menghubungkan ke ${printer.address}');

    final success = await PrintBluetoothThermal.connect(
      macPrinterAddress: printer.address,
    );

    if (!success) {
      throw Exception('Gagal terhubung ke printer Bluetooth');
    }

    // Tunggu agar device siap menerima data.
    await Future.delayed(const Duration(milliseconds: 500));

    _currentPrinter = printer;
  }

  /// Putuskan koneksi aktif.
  static Future<void> disconnect() async {
    await _disconnectCurrent();
    _currentPrinter = null;
  }

  static Future<void> _disconnectCurrent() async {
    try {
      final connected = await PrintBluetoothThermal.connectionStatus;
      if (connected) {
        await PrintBluetoothThermal.disconnect;
        await Future.delayed(const Duration(milliseconds: 200));
      }
    } catch (_) {}
  }

  static bool _isSamePrinter(PrinterModel printer) {
    return _currentPrinter != null &&
        _currentPrinter!.connection == printer.connection &&
        _currentPrinter!.address == printer.address &&
        _currentPrinter!.port == printer.port;
  }
}